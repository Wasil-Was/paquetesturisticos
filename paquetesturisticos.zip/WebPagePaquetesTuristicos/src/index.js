const bodyParser = require ('body-parser');
const express = require ('express');
const app = express();
const path = require ('path');

//CONFIGURACIÓN INICIAL
app.set('port',process.env.PORT || 3000);

//MIDDLEWARE (Lógica de Intercambio de Información.)
app.use(express.json());

//RUTAS (Rutas de datos e información.)
app.use(require('./routes/all'));

//SERVIDOR
app.listen(app.get('port'), ()=> {
    console.log('Servidor en Puerto',app.get('port'))
});