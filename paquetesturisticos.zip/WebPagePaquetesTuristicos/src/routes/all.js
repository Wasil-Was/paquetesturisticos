const express = require('express');

const con = require('../ConnectBD');

//CONSULTAS:
//SELECT
con.query('SELECT cliente.Nombre, cliente.Rut, cliente.ID_Paquete, pago.Valor from cliente inner join pago on cliente.Rut = pago.Rut where pago.Valor > 600000', (err,resp,campos) =>{
    console.log(resp);
});
con.query('SELECT ruta.ID_Ruta, ruta.Pais_Origen, ruta.Pais_Destino, vuelo.modeloAvion from ruta inner join vuelo on ruta.ID_Ruta = vuelo.ID_Ruta', (err,resp,campos) =>{
    console.log(resp);
});
con.query('SELECT ID_Vuelo, modeloAvion, Capacidad from vuelo where capacidad >= 500', (err,resp,campos) =>{
    console.log(resp);
});


//INSERT
var sql = "INSERT INTO ruta(ID_Ruta, Aeropuerto_Origen, Aeropuerto_Destino, Pais_Origen, Pais_Destino, Fecha_Ida, Fecha_Vuelta, Hora_Salida, Hora_Vuelta) values ?";
var data = [
    ['1616', 'Aeropuerto de Chile', 'Aeropuerto de Uruguay', 'Chile', 'Uruguay', '2021-12-1', '2022-02-1', '00:00', '1:30']
];
  con.query(sql, [data], (err, resp, campos) =>{
    if (err) {
        return console.error(err.message);
    }
    console.log('\nObjetos Ingresados: ' + resp.affectedRows);
});
var sql = "INSERT INTO vuelo(ID_Vuelo, ID_Ruta, modeloAvion, Capacidad) values ?";
var data = [
    ['686', '1616', 'Boeing 727', '50']
];
  con.query(sql, [data], (err, resp, campos) =>{
    if (err) {
        return console.error(err.message);
    }
    console.log('\nObjetos Ingresados: ' + resp.affectedRows);
});
var sql = "INSERT INTO pasaje(ID_Pasaje, ID_Vuelo, Clase, Asiento, Valor) values ?";
var data = [
    ['80686', '686', 'Economica', '69', '300000']
];
  con.query(sql, [data], (err, resp, campos) =>{
    if (err) {
        return console.error(err.message);
    }
    console.log('\nObjetos Ingresados: ' + resp.affectedRows);
});


//DELETE
con.query('DELETE from pasaje where ID_Pasaje = 80686', (err,resp,campos) =>{
    console.log(resp);
});
con.query('DELETE from vuelo where ID_Vuelo = 686', (err,resp,campos) =>{
    console.log('\n\n\n\n\n\n\n\n',resp);
});

//UPDATE
con.query('UPDATE ruta set Aeropuerto_Origen = "A.Inter.Arturo Merino Benítez" where Aeropuerto_Origen = "Aeropuerto de Chile"', (err,resp,campos) =>{
    console.log(resp);
});
con.query('UPDATE vuelo set modeloAvion = "Boeing 777" where modeloAvion = "Boeing 747"', (err,resp,campos) =>{
    console.log(resp);
});



//CREATE
con.query('CREATE table TablaGenerica (nombre varchar(20) NOT NULL, apellido varchar(20) NOT NULL, edad int NOT NULL, telefono int NOT NULL)', (err,resp,campos) =>{
    console.log(resp);
});


//ALTER
con.query('ALTER table TablaGenerica add Rut varchar(10) NOT NULL first', (err,resp,campos) =>{
    console.log(resp);
});
con.query('ALTER table TablaGenerica add primary key (Rut)', (err,resp,campos) =>{
    console.log(resp);
});


//DROP
con.query('DROP table TablaGenerica', (err,resp,campos) =>{
    console.log(resp);
});



/* EJEMPLOS:
//TEST
//console.log("Hola!");

con.query('SELECT * from paquetes', (err,resp,campos) =>{
    console.log(resp, "\n\n\n\n");
});

con.query('SELECT rut from paquetes', (err,resp,campos) =>{
    console.log(resp);
});

con.query('DELETE from paquetes WHERE paquetes.rut = 20483921', (err,resp,campos) =>{
    console.log(resp);
});

con.query('UPDATE paquetes SET rut="33333333" WHERE paquetes.rut = 22222222', (err,resp,campos) =>{
    console.log(resp);
});

var sql = "INSERT INTO paquetes(rut, vivo, edad, fechaDeNacimiento) VALUES ?";
var data = [
    ['20531130', '1', '21', '2000-05-12'],
    ['20031059', '0', '17', '1997-07-09'],
    ['20483921', '1', '21', '2000-09-15']
];
  con.query(sql, [data], (err, resp, campos) =>{
    if (err) {
        return console.error(err.message);
    }
    console.log('\nObjetos Ingresados: ' + resp.affectedRows);
});

  con.query('SELECT * from paquetes', (err,resp,campos) =>{
    console.log("\n\n\n\n",resp);
});
*/